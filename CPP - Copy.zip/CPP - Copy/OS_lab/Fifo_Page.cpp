#include<bits/stdc++.h>  
using namespace std;
#define endl "\n"
#define int long long int
#define no          cout<<"NO\n"
#define yes         cout<<"YES\n"
#define tests       int t; cin >> t;  while (t--)
#define sai         ios_base::sync_with_stdio(0);cin.tie(0);
typedef vector<int>vi;
#define all(v)        v.begin(),v.end()
//___________________________________________________________________________________________//
void printqueue(queue<int>q)
{
    while (!q.empty())
    {
        cout<<" "<<q.front();
        q.pop();
    }
    cout<<endl;
}
void solve()
{
    int n;
    cin>>n;
    vi v(n);
    for(auto &i:v)cin>>i;

    int frames;
    cin>>frames;

    int pagefault=0;
    map<int,int>mp;
    queue<int>q;
    for(int i=0;i<n;i++)
    {
        if(mp.find(v[i])!=mp.end())continue;
        else
        {
            mp[v[i]]++;
            pagefault++;
            if(q.size()<frames)
            {
                q.push(v[i]);
            }
            else
            {
                int a=q.front();
                mp.erase(a);
                q.pop();
                q.push(v[i]);
            }

        }
        printqueue(q);
    }
    cout<<pagefault<<endl;
}
signed main()
{
     sai
    // tests
    solve();
     
}