#include<bits/stdc++.h>  
using namespace std;
#define endl "\n"
#define no          cout<<"NO\n"
#define yes         cout<<"YES\n"
#define tests       int t; cin >> t;  while (t--)
#define sai         ios_base::sync_with_stdio(0);cin.tie(0);
typedef vector<int>vi;
#define all(v)        v.begin(),v.end()
//___________________________________________________________________________________________//
int t=0;
bool ok(vector<pair<int,int>>&v,int key)
{
    for(auto &i:v)
    {
        if(i.first==key)
        {
            i.second=t++;
            return true;
        }
    }
    return false;
}
int minindex(vector<pair<int,int>>&v)
{
    int ind=-1;
    int mini=1e9;
    for(int i=0;i<v.size();i++)
    {
        if(v[i].second<mini)
        {
            mini=v[i].second;
            ind=i;
        }
    }
    return ind;
}
void solve()
{
    int n;
    cin>>n;
    vi v(n);
    for(auto &i:v)cin>>i;

    int frames;
    cin>>frames;

    vector<pair<int,int>>vp;

    int pagefaults=0;
    
    for(int i=0;i<n;i++)
    {
        if(ok(vp,v[i]))continue;

        else
        {
            pagefaults++;
            if(vp.size()<frames)
            {
                vp.push_back({v[i],t++});
            }
            else
            {
                int index=minindex(vp); 
                vp[index]={v[i],t++};
            }
        }
        for(auto i:vp)
            cout<<i.first<<" ";
        cout<<endl;
    }
    cout<<pagefaults<<endl;

}
signed main()
{
     sai
    // tests
    solve();
     
}