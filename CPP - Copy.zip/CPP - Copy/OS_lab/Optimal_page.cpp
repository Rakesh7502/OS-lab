#include<bits/stdc++.h>  
using namespace std;
#define endl "\n"
#define no          cout<<"NO\n"
#define yes         cout<<"YES\n"
#define tests       int t; cin >> t;  while (t--)
#define sai         ios_base::sync_with_stdio(0);cin.tie(0);
typedef vector<int>vi;
#define all(v)        v.begin(),v.end()
//___________________________________________________________________________________________//

bool ok(vector<int>&v,int key)
{
    for(auto &i:v)
    {
        if(i==key)return true;
    }
    return false;
}

void solve()
{
    int n;
    cin>>n;
    vi v(n);
    for(auto &i:v)cin>>i;

    int frames;
    cin>>frames;


    int pagefaults=0;
    vi vp;
    for(int i=0;i<n;i++)
    {
        if(ok(vp,v[i]))continue;
        else
        {

            pagefaults++;
            if(vp.size()<frames)
            {
                vp.push_back(v[i]);
            }
            else 
            {
                int ind=0;
                int mindist=-1e9;
                for(int j=0;j<frames;j++)
                {
                    int dis=100;
                    for(int k=i+1;k<n;k++)
                    {
                        if(v[j]==v[k])
                        {
                            dis=k-i-1;
                            break;
                        }
                    }
                    if(mindist<dis)
                    {
                        ind=j;
                        mindist=dis;
                    }
                }

                vp[ind]=v[i];
            }
        }
        for(auto i:vp)cout<<i<<" ";cout<<endl;

    }
    cout<<pagefaults<<endl;


}
signed main()
{
     sai
    // tests
    solve();
     
}