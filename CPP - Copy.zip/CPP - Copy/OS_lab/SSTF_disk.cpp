#include<bits/stdc++.h>  
using namespace std;
#define endl "\n"
#define int long long int
#define no          cout<<"NO\n"
#define yes         cout<<"YES\n"
#define tests       int t; cin >> t;  while (t--)
#define sai         ios_base::sync_with_stdio(0);cin.tie(0);
typedef vector<int>vi;
#define all(v)        v.begin(),v.end()
//___________________________________________________________________________________________//

void solve()
{
    int n;
    cin>>n;
    vi v(n);
    for(auto &i:v)cin>>i;
    int head,total;
    cin>>head;
    cin>>total;

    int headmoves=0;
    
    sort(all(v));
    int up=upper_bound(all(v),head)-v.begin();
    if(v[up]-head<head-v[up-1])
    {
        for(int i=up;i<n;i++)
        {
            headmoves+=abs(v[i]-head);
            head=v[i];
            cout<<v[i]<<" ";
        }
        for(int i=up-1;i>=0;i--)
        {
            headmoves+=head-v[i];
            head=v[i];
            cout<<v[i]<<" ";
        }
    }
    else
    {
        for(int i=up-1;i>=0;i--)
        {
            headmoves+=head-v[i];
            head=v[i];
            cout<<v[i]<<" ";
        }
        for(int i=up;i<n;i++)
        {
            headmoves+=abs(v[i]-head);
            head=v[i];
            cout<<v[i]<<" ";
        }
    }
    cout<<endl<<headmoves<<endl;

}
signed main()
{
     sai
    // tests
    solve();
     
}