#include "bits/stdc++.h"
using namespace std;

int main()
{
    int n;
    cin>>n;
    vector<int>v(n);
    for(auto &i:v)cin>>i;

    int head=0;
    cin>>head;
    int total;
    cin>>total;
    sort(v.begin(),v.end());
    
    
    int ind=0;
    for(int i=0;i<n;i++)
    {
        if(v[i]>head)
        {
            ind=i;
            break;
        }
    }
    int headmoves=0;
    
    if(head<=v[0])
    {
        cout<<head<<" ";
        for(int i=0;i<n; i++)
        {
            headmoves+=v[i]-head;
            head=v[i];
            cout<<v[i]<<" ";
        }
    }
    else if(head>v[0] and head<=v[n-1])
    {
        cout<<head<<" ";
        for(int i=ind;i<n;i++)
        {
            cout<<v[i]<<" ";
            headmoves+=v[i]-head;
            head=v[i];
        }
       

        for(int i=ind-1;i>=0;i--)
        {
            cout<<v[i]<<" ";
            headmoves+=head-v[i];
            head=v[i];
        }
    }
    else
    {
        cout<<head<<" ";
        
       
        for(int i=n-1;i>=0;i--)
        {
            cout<<v[i]<<" ";
            headmoves+=head-v[i];
            head=v[i];
        }
    }
    cout<<endl<<headmoves<<endl;

}