cout<<"total internal fragmentation:"<<internal<<endl;
    // cout<<"total external fragmentation:"<<exte