#include<stdio.h>
int main(){
    printf("enter the block size : ");
    int n,m,i,j;
    scanf("%d",&n);
    printf("enter the available blocks mm: ");
    int a[n];
    // scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("enter the processor size : ");
    scanf("%d",&m);
    int b[m];
    printf("enter the processro sizes : ");
    for(i=0;i<m;i++){
        scanf("%d",&b[i]);
    }
    int c[m],index;
    for(i=0;i<m;i++){
        c[i]=-1;
        int min=99999;
        int size=b[i];
        for(j=0;j<n;j++){
            if(a[j]>=size){
                printf("%d ",j);
                a[j]-=size;
                break;
            }
        }
        if(j==n)
        printf("%d",-1);
        // if(min!=99999){
        //     c[i]=index;
        //     a[index]-=size;
        // }
    }
    // for(i=0;i<m;i++){
    //     printf("%d ",c[i]);
    // }

}